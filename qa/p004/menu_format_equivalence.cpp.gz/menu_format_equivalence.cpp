
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <random>
#include <limits>
#include <cstdint>
#include <iostream>
#include <vector>
#define LCD_COLUMNS 16
#define VALUE_MAX_DIGITS 4
enum menu_type {VALUE,OPTION,ACTION};
struct menu_item {
  const char* name_;
  menu_type type;
  int value;
  int decimals;
  int lim;
  const char* options[4];
  const char* suffix;
};
menu_item menu[12]{};
double value_dbl=0;
char value_str[16]{};
char* dtostrf(double value, signed char width, unsigned char prec, char* out){
  snprintf(out,16,"%*.*f",int(width),int(prec),value);
  return out;
}

void format_menu_line_old(int index, char *line){
  char full[48];
  snprintf(full, sizeof(full), "%d|%s", index, menu[index].name_);
  if (menu[index].type == VALUE){
    value_dbl = menu[index].value / pow(10, menu[index].decimals);
    dtostrf(value_dbl, VALUE_MAX_DIGITS, menu[index].decimals, value_str);
    strncat(full, " ", sizeof(full) - strlen(full) - 1);
    strncat(full, value_str, sizeof(full) - strlen(full) - 1);
    strncat(full, menu[index].suffix, sizeof(full) - strlen(full) - 1);
  } else if (menu[index].type == OPTION){
    strncat(full, " ", sizeof(full) - strlen(full) - 1);
    strncat(full, menu[index].options[menu[index].value], sizeof(full) - strlen(full) - 1);
  }
  memset(line, ' ', LCD_COLUMNS);
  line[LCD_COLUMNS] = '\0';
  size_t count = strlen(full);
  if (count > LCD_COLUMNS) count = LCD_COLUMNS;
  memcpy(line, full, count);
}

void format_menu_line_new(int index, char *line){
  // The LCD displays only 16 characters. Avoid a separate 48-byte stack buffer.
  snprintf(line, LCD_COLUMNS + 1, "%d|%s", index, menu[index].name_);
  if (menu[index].type == VALUE){
    value_dbl = menu[index].value / pow(10, menu[index].decimals);
    dtostrf(value_dbl, VALUE_MAX_DIGITS, menu[index].decimals, value_str);
    strncat(line, " ", LCD_COLUMNS - strlen(line));
    strncat(line, value_str, LCD_COLUMNS - strlen(line));
    strncat(line, menu[index].suffix, LCD_COLUMNS - strlen(line));
  } else if (menu[index].type == OPTION){
    strncat(line, " ", LCD_COLUMNS - strlen(line));
    strncat(line, menu[index].options[menu[index].value], LCD_COLUMNS - strlen(line));
  }
  const size_t used = strlen(line);
  memset(line + used, ' ', LCD_COLUMNS - used);
  line[LCD_COLUMNS] = '\0';
}


int main(){
  std::mt19937 g(20261103);
  std::string chars="ABCDEFGHIJKLMNO_!#- /XYZ0123456789";
  unsigned n=0, value=0, options=0, actions=0;
  for(int trial=0;trial<30000;trial++){
    const int idx=trial%12;
    const int name_len=trial%6==0 ? 60+(trial%40): g()%45;
    const int opt_len=trial%7==0? 72+(trial%19):g()%45;
    const int suf_len=trial%11==0? 73+(trial%19):g()%45;
    std::string name,suf,option;
    for(int i=0;i<name_len;i++)name+=chars[g()%chars.size()];
    for(int i=0;i<suf_len;i++)suf+=chars[g()%chars.size()];
    for(int i=0;i<opt_len;i++)option+=chars[g()%chars.size()];
    const menu_type ty=(menu_type)(trial%3);
    const int setting=ty==VALUE ? (int)(g()%65536)-32768 : (ty==OPTION?int(g()%4):0);
    menu[idx]={name.c_str(),ty,setting,trial%4,32767,{option.c_str(),option.c_str(),option.c_str(),option.c_str()},suf.c_str()};
    char a[20],b[20];
    memset(a,0x5a,sizeof(a));
    memset(b,0x5a,sizeof(b));
    format_menu_line_old(idx,a);
    format_menu_line_new(idx,b);
    if (memcmp(a,b,LCD_COLUMNS+1)!=0 ||
        a[17]!=0x5a||b[17]!=0x5a||b[16]!='\0'){
       fprintf(stderr,"DIFF trial=%d type=%d name=%s suf=%s old=%.*s new=%.*s\n",trial,(int)ty,name.c_str(),suf.c_str(),LCD_COLUMNS,a,LCD_COLUMNS,b);
       return 1;
    }
    if (ty==VALUE)value++;else if(ty==OPTION)options++;else actions++;
    n++;
  }
  printf("PASS:%u cases; VALUE=%u OPTION=%u ACTION=%u; F_CPU=%lu\n",n,value,options,actions,(unsigned long)F_CPU);
}
