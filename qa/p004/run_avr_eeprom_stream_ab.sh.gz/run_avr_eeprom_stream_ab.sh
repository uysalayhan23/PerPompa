#!/usr/bin/env bash
set -euo pipefail
root="$RUNNER_TEMP/p004-store"
report="$root/report"
mkdir -p "$root/base" "$report"
echo 'b9d04926776ce3703043c507fa804c6cc6ff6ca494f84df6b6926b37ff3d38f2  qa/p004/read_only_candidate.tar.gz' | sha256sum -c -
tar -xzf qa/p004/read_only_candidate.tar.gz -C "$root/base"
cp -a "$root/base" "$root/stream"
for variant in base stream; do
  python3 qa/p004/flash_lcd_literals_candidate.py "$root/$variant/Peristaltic_Pump_Software_v1.06/Peristaltic_Pump_Software_v1.06.ino"
done
echo '83add43e3016e0cd1f9fd1ed6ec29850d9616de9c196a08d692a8893d5110dc8  qa/p004/p0-04-store-stream-qa.h' | sha256sum -c -
cp qa/p004/p0-04-store-stream-qa.h "$root/stream/Peristaltic_Pump_Software_v1.06/p0-04-settings-store.h"
for variant in base stream; do
  echo '5c7009477ba56cb70850f22ece9860fcb222bd4c0a0c3a10622c21b66c79bfa5  '"$root"'/'"$variant"'/Peristaltic_Pump_Software_v1.06/Peristaltic_Pump_Software_v1.06.ino' | sha256sum -c -
done
getaddr() { awk -v wanted="$2" '$3==wanted {v=$1;sub(/^0080/,"",v);print v;exit}' "$1"; }
for entry in '16MHz arduino:avr:pro:cpu=16MHzatmega328 16000000' '8MHz arduino:avr:pro:cpu=8MHzatmega328 8000000'; do
  read -r clk fqbn hz <<< "$entry"
  for variant in base stream; do
    sketch="$root/$variant/Peristaltic_Pump_Software_v1.06"
    build="$root/build-$clk-$variant"
    arduino-cli compile --fqbn "$fqbn" --build-path "$build" "$sketch" > "$report/compile-$clk-$variant.log" 2>&1
    grep -E 'Sketch uses|Global variables use' "$report/compile-$clk-$variant.log" | tee -a "$report/RESULT.txt"
    elf=$(find "$build" -type f -name '*.elf' -print -quit)
    test -f "$elf"
    avr-size -A "$elf" > "$report/sections-$clk-$variant.txt"
    avr-nm -n -C "$elf" > "$report/symbols-$clk-$variant.txt"
    nmfile="$report/symbols-$clk-$variant.txt"
    brk=$(getaddr "$nmfile" '__brkval'); bss=$(getaddr "$nmfile" '__bss_end')
    lcd=$(getaddr "$nmfile" 'lcd_init_ok'); mn=$(getaddr "$nmfile" 'menu_number_1')
    hw=$(getaddr "$nmfile" 'hwUiActive'); reviewed=$(getaddr "$nmfile" 'migrationReviewAccepted')
    action=$(getaddr "$nmfile" 'in_action'); menu=$(getaddr "$nmfile" 'menu')
    for symbol in "$brk" "$bss" "$lcd" "$mn" "$hw" "$reviewed" "$action" "$menu"; do
      test -n "$symbol" || { echo "MISSING_RUNTIME_SYMBOLS_$clk-$variant=REVIEW"; exit 1; }
    done
    if timeout 75s "$root/stack_store_uart_probe" "$elf" "$hz" "$brk" "$bss" "$lcd" "$mn" "$hw" "$reviewed" "$action" "$menu" > "$report/simavr-$clk-$variant.txt" 2>&1; then
      echo "SIMAVR_$clk-$variant=TRACE_OK" | tee -a "$report/RESULT.txt"
    else
      echo "SIMAVR_$clk-$variant=REVIEW" | tee -a "$report/RESULT.txt"
    fi
    grep -E '^SIMAVR_(STACK_DEPTH_OBSERVED|STACK_HEAP_GAP_OBSERVED|EEPROM_SAVE_STAGED|EEPROM_WITNESS_OBSERVED|EEPROM_COMMITTED|UART_RX_STIMULI|CPU_STATE)=' "$report/simavr-$clk-$variant.txt" | tee -a "$report/RESULT.txt" || true
    diag="$root/diag-$clk-$variant"
    if arduino-cli compile --fqbn "$fqbn" --build-path "$diag" \
      --build-property 'compiler.cpp.extra_flags=-fno-lto -fstack-usage' \
      --build-property 'compiler.c.extra_flags=-fno-lto -fstack-usage' \
      "$sketch" > "$report/diagnostic-$clk-$variant.log" 2>&1; then
      find "$diag" -type f -name '*.su' -exec cat {} + > "$report/frames-$clk-$variant.txt"
      grep 'Store<EEPROMClass>::decode' "$report/frames-$clk-$variant.txt" | head -n 1 | tee -a "$report/RESULT.txt" || true
    fi
  done
done
python3 - "$report" <<'PY'
from pathlib import Path
import re,json,sys
p=Path(sys.argv[1]);d={}
for clk in ('16MHz','8MHz'):
  for kind in ('base','stream'):
    log=(p/f'compile-{clk}-{kind}.log').read_text()
    z={'SRAM':int(re.search(r'Global variables use (\d+) bytes',log).group(1)),
       'FLASH':int(re.search(r'Sketch uses (\d+) bytes',log).group(1))}
    for line in (p/f'simavr-{clk}-{kind}.txt').read_text().splitlines():
      if line.startswith('SIMAVR_') and '=' in line:
        a,b=line.split('=',1);z[a]=b
    f=p/f'frames-{clk}-{kind}.txt'
    match=re.search(r'Store<EEPROMClass>::decode[^\n]*\t(\d+)\t',f.read_text() if f.exists() else '')
    z['DECODE_FRAME']=int(match.group(1)) if match else None
    d[f'{clk}-{kind}']=z
  a,b=d[f'{clk}-base'],d[f'{clk}-stream']
  print(f'{clk}: STORE_FRAME {a["DECODE_FRAME"]}->{b["DECODE_FRAME"]}, SRAM {a["SRAM"]}->{b["SRAM"]}, SIM_GAP {a.get("SIMAVR_STACK_HEAP_GAP_OBSERVED")}->{b.get("SIMAVR_STACK_HEAP_GAP_OBSERVED")}')
  if b['SRAM']>a['SRAM'] or b['DECODE_FRAME'] is None or a['DECODE_FRAME'] is None or b['DECODE_FRAME']>=a['DECODE_FRAME']:
    raise SystemExit('REVIEW: no demonstrated AVR frame/overall SRAM improvement')
  if b.get('SIMAVR_STACK_HEAP_GAP_OBSERVED') and a.get('SIMAVR_STACK_HEAP_GAP_OBSERVED'):
    if int(b['SIMAVR_STACK_HEAP_GAP_OBSERVED'])<int(a['SIMAVR_STACK_HEAP_GAP_OBSERVED']):
      raise SystemExit('REVIEW: simulated runtime stack gap declined')
  for kind in ('base','stream'):
    x=d[f'{clk}-{kind}']
    if x.get('SIMAVR_EEPROM_COMMITTED')!='1' or int(x.get('SIMAVR_UART_RX_STIMULI','0'))<3:
      print(f'REVIEW: EEPROM save + UART timing not fully reached in {clk} {kind}')
(p/'COMPARISON.json').write_text(json.dumps(d,indent=2))
print('AVR_DIAGNOSTIC_FRAME_A_B_PASS;ALL_PATHS_STACK_HEAP_REVIEW;PHYSICAL_NOT_RUN;RELEASE_BLOCKED')
PY
