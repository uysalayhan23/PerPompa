#ifndef PERPOMPA_P004_RECOVERY_UI_H
#define PERPOMPA_P004_RECOVERY_UI_H
// Review-only local operator UI gate. Never makes the pump ready to start.
namespace perpompa_recovery_ui {
struct Conditions {
  bool physicalHold;
  bool atHwSetup;
  bool noOtherMenu;
  bool hwUiIdle;
  bool lcdReady;
  bool motorIdle;
  bool remoteIdle;
  bool usbIdle;
  bool migrationLocked;
};
inline bool authorized(const Conditions &c) {
  return c.physicalHold && c.atHwSetup && c.noOtherMenu &&
         c.hwUiIdle && c.lcdReady && c.motorIdle && c.remoteIdle &&
         c.usbIdle && c.migrationLocked;
}
template<class Gate> bool tryRecovery(Gate &gate, const Conditions &c) {
  if (!authorized(c)) return false;
  return gate.recoverInterruptedFirstSave(true, c.motorIdle, c.remoteIdle, c.usbIdle);
}
} // namespace perpompa_recovery_ui
#endif
