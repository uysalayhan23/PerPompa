# P0-04 Flash LCD full-source host QA — 3 November 2026

**Review-only; no firmware upload, no GitHub Actions, no device or deployment access.**

- Source: `qa/p004/read_only_candidate.tar.gz` (SHA256 `b9d04926776ce3703043c507fa804c6cc6ff6ca494f84df6b6926b37ff3d38f2`) plus the SHA-locked five-line patch `flash_lcd_literals_candidate.py`. Exact final `.ino` SHA256: `5c7009477ba56cb70850f22ece9860fcb222bd4c0a0c3a10622c21b66c79bfa5`.
- New (not previously rerun) cases: 12 actual `setup()/loop()` cases per compiler and host F_CPU (GCC and Clang, 8 and 16 MHz), **48/48 PASS** with UBSan; **48/48 PASS** with ASan+UBSan.
- Five deliberate LCD text mutants x four compiler/F_CPU combinations = **20/20 EXPECTED_FAIL** in each sanitizer suite. Includes exit action clear text, recovery notice, reboot text, service hold, physical review prompt.
- Host mock emulates Arduino GPIO, I2C LCD print and EEPROM, Serial, ClickEncoder. Host `F(s)` shim preserves literal content only; **AVR Flash address-space compilation was separately verified** by GitHub Actions run `41645418905`. No real board or stack peak evidence is claimed.
- Source motor lock, Remote, invalid USB and LCD fail-closed paths were exercised. This is targeted integrated native regression, **not** an exhaustive whole-product test or all interrupt timing profile.
- Global stack/heap safety stays **REVIEW**: 205 B observed free gap from bounded simAVR; full ISR/EEPROM/USB/menu combinations and physical high water not proven. `PHYSICAL_NOT_RUN`, `RELEASE_BLOCKED`.

To reproduce from the repository root without modifying production firmware: `bash qa/p004/run_flash_fullsource_native_review.sh` (requires local GCC and Clang; never calls Arduino CLI or a programmer). The wrapper extracts the temporary candidate into a disposable directory, applies the SHA-locked patch, and runs only this new QA suite.
