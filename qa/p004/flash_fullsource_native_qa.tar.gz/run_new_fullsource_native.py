#!/usr/bin/env python3
"""P004 Flash LCD new source/loop positive-negative test. No earlier suites rerun."""
from pathlib import Path
import hashlib, tempfile, subprocess, sys, json
R=Path(__file__).resolve().parent
SRC=R/'sketch'/'Peristaltic_Pump_Software_v1.06.ino'
HEADERS=R/'sketch'
SHA='5c7009477ba56cb70850f22ece9860fcb222bd4c0a0c3a10622c21b66c79bfa5'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==SHA
prelude=(R/'host_prelude.cpp').read_text()
raw=SRC.read_text()
runner=(R/'new_flash_fullsource_cases.inc').read_text()
assert '//LCD ' in raw
cases=['legacy_prompt','recovery_notice','reboot_notice','service_hold','reboot_lock_serial','normal_menu_dismiss','lcd_init_fail','remote_rejected_during_review','physical_legacy_save','legacy_save_untrusted_usb','exit_action_clears_lcd','menu_format_sweep']
mutants={
'wrong_legacy_prompt':('F("HOLD TO CONFIRM ")','F("HOLD TO CONFI  ")','legacy_prompt'),
'wrong_reboot_overlay':('F("REBOOT TO CHECK ")','F("REBOOT TO CHEC  ")','reboot_notice'),
'wrong_service_hold':('F("DO NOT ERASE    ")','F("DO NOT ERASE?   ")','service_hold'),
'wrong_recovery_notice':('F("RECOVERY REVIEW ")','F("RECOVERY REVIEX ")','recovery_notice'),
'wrong_action_exit_clear':('F("          ")','F("         ")','exit_action_clears_lcd'),
}
result=[]
with tempfile.TemporaryDirectory(prefix='p004_flash_source_') as temp:
    temp=Path(temp)
    for variant,mut in [('PATCH',None),*mutants.items()]:
        source=raw
        if mut:
            original,replacement,case=mut
            assert source.count(original)>=1,original
            source=source.replace(original,replacement)
        cpp=temp/(variant+'.cpp')
        cpp.write_text(prelude+'\n#define F(s) (s) // host-only stub, AVR F overload tested separately\n'+'//LCD '+source.split('//LCD ',1)[1]+'\n'+runner)
        for compiler in ('g++','clang++'):
            for freq in (8000000,16000000):
                exe=temp/(variant+'_'+compiler.replace('+','p')+'_'+str(freq))
                args=[compiler,'-std=c++17','-O0','-w','-fsanitize=undefined','-fno-sanitize-recover=all',f'-DF_CPU={freq}UL','-I',str(HEADERS),str(cpp),'-o',str(exe)]
                comp=subprocess.run(args,capture_output=True,text=True)
                if comp.returncode:
                    raise SystemExit('COMPILE_FAIL '+variant+' '+compiler+' '+str(freq)+'\n'+comp.stderr[-2500:])
                targets=cases if not mut else [mut[2]]
                for case in targets:
                    x=subprocess.run([str(exe),case],capture_output=True,text=True)
                    success=(x.returncode==0) if not mut else (x.returncode==2)
                    if not success:
                        raise SystemExit(f'BAD_RESULT {variant} {compiler} {freq} {case} exit={x.returncode}\n{x.stdout}\n{x.stderr}')
                    result.append(dict(kind=variant,compiler=compiler,f_cpu=freq,case=case,status='PASS' if not mut else 'EXPECTED_MUTANT_BLOCK',stdout=x.stdout.strip(),stderr=x.stderr.strip()))
    print('NEW_FLASH_NATIVE_SOURCE_CASES',len(cases)*4,'PASS')
    print('NEW_FLASH_MESSAGE_NEGATIVE_MUTANTS',len(mutants)*4,'BLOCKED')
    print('NO_OLD_SUITES_REPEATED;HOST_MOCK_NOT_AVR;PHYSICAL_NOT_RUN;RELEASE_BLOCKED')
(R/'NEW_FLASH_FULL_SOURCE_NATIVE_RESULT.json').write_text(json.dumps({'sha256':SHA,'results':result},indent=2))
