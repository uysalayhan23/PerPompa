
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#define HIGH 1
#define LOW 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define A0 14
using byte=unsigned char;
using boolean=bool;
using String=std::string;
unsigned long nowMs=200;
int pins[32]{};
int stepHighs=0,stepLows=0;
unsigned long elapsedUs=0;
unsigned long millis(){return nowMs;}
void delay(unsigned long ms){nowMs+=ms;}
void delayMicroseconds(unsigned int us){elapsedUs+=us;}
void pinMode(int,int){}
int digitalRead(int p){return pins[p];}
void digitalWrite(int p,int level){pins[p]=level;if(p==7){if(level==HIGH)stepHighs++;else stepLows++;}}
bool lcdBeginOk=true;
class hd44780_I2Cexp {
public:
 int currentRow=0,currentCol=0;
 std::string lastPrint[2];
 int begin(int,int){return lcdBeginOk?0:1;}
 void blink(){}void noBlink(){}
 void setCursor(int x,int y){currentCol=x;currentRow=y;}
 size_t print(const char* s){if(currentRow>=0 && currentRow<2)lastPrint[currentRow]=s;return std::strlen(s);}
 size_t write(char c){if(currentRow>=0&&currentRow<2){if(lastPrint[currentRow].size()<=size_t(currentCol))lastPrint[currentRow].resize(currentCol+1,' ');lastPrint[currentRow][currentCol]=c;}currentCol++;return 1;}
 size_t write(unsigned char c){return write((char)c);}
};
class ClickEncoder {
public:
enum Button {Open,Pressed,Held,Released,Clicked,DoubleClicked};
Button button=Open;int16_t delta=0;
ClickEncoder(int,int,int,int){}
void service(){}void setAccelerationEnabled(bool){}
Button getButton(){Button b=button;button=Open;return b;}
int16_t getValue(){int16_t v=delta;delta=0;return v;}
};
struct TimerMock {void initialize(unsigned long){}void attachInterrupt(void(*)()){} } Timer1;
struct EepromMock {
byte memory[1024];int readCount=0;int updateCount=0;int interruptAt=-1;
EepromMock(){reset();}
void reset(){std::memset(memory,0xff,sizeof(memory));readCount=0;updateCount=0;interruptAt=-1;}
byte read(int a){readCount++;if(a<0||a>=1024)std::abort();return memory[a];}
void write(int a,byte b){if(a<0||a>=1024)std::abort();memory[a]=b;}
void update(int a,byte b){if(interruptAt>=0 && updateCount>=interruptAt)throw 123;updateCount++;write(a,b);}
};using EEPROMClass=EepromMock;EepromMock EEPROM;
struct SerialMock {
std::string buffer;size_t offset=0;
void begin(int){}
int available(){return static_cast<int>(buffer.size()-offset);}
int read(){return available()?static_cast<unsigned char>(buffer[offset++]):-1;}
long parseInt(){
while(available() && buffer[offset]!='-' && (buffer[offset]<'0'||buffer[offset]>'9'))offset++;
bool neg=false;
if(available()&&buffer[offset]=='-'){neg=true;offset++;}
long v=0;
while(available()&&buffer[offset]>='0'&&buffer[offset]<='9')v=v*10+(buffer[offset++]-'0');
return neg?-v:v;
}
void inject(const char *s){buffer=s;offset=0;}
void reset(){buffer.clear();offset=0;}
} Serial;
char* dtostrf(double v,signed char w,unsigned char p,char* out){
std::snprintf(out,16,"%*.*f",(int)w,(int)p,v);return out;
}

#include "p0-02-usb-parser.h"
void setup();
void loop();
void timerIsr();
int8_t read_encoder_step();
void set_rng_running(bool running);
bool saveSettingsAtomic();
void usbApplyEvent(const perpompa_usb::Event &e);
void hwForceIdle();
bool hwMotorAllowed();
void remote_start();
void remote_stop();
void handle_remote_input();
boolean dose(long _steps, int _delay_us, long & inc);
void dose_slow(long _steps, int _delay_us, long & inc);
void pump(int _delay_us);
void exit_action_menu();
long steps_calc(long volume, int unit_mode, int calibr, int decimals);
long delay_us_calc(long vol_per_min, int unit_mode, int calibr, int decimals);
void format_menu_line(int index, char *line);
void update_lcd();
boolean encoder_selection(int & x, int lim);
boolean encoder_value_selection(int & x, int lim);
boolean encoder_selection(int & x, int & y, int lim);
int eepromReadInt(int adr);

#include "p0-02-usb-parser.h"
void setup();
void loop();
void timerIsr();
int8_t read_encoder_step();
void set_rng_running(bool running);
bool saveSettingsAtomic();
void usbApplyEvent(const perpompa_usb::Event &e);
void hwForceIdle();
bool hwMotorAllowed();
void remote_start();
void remote_stop();
void handle_remote_input();
boolean dose(long _steps, int _delay_us, long & inc);
void dose_slow(long _steps, int _delay_us, long & inc);
void pump(int _delay_us);
void exit_action_menu();
long steps_calc(long volume, int unit_mode, int calibr, int decimals);
long delay_us_calc(long vol_per_min, int unit_mode, int calibr, int decimals);
void format_menu_line(int index, char *line);
void update_lcd();
boolean encoder_selection(int & x, int lim);
boolean encoder_value_selection(int & x, int lim);
boolean encoder_selection(int & x, int & y, int lim);
int eepromReadInt(int adr);
// include the library code:








#include "hw-setup-runtime.h"
#include "p0-02-usb-parser.h"
#include "p0-04-settings-store.h"
#include "p004-migration-guard-candidate.h"
#include "p004-recovery-ui.h"
bool saveSettingsAtomic();


